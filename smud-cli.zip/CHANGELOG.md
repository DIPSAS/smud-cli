## Version 1.0.1
- Implmented `smud apply`

## Version 1.0.0
- Initial commit